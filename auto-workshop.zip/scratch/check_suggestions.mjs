import { createClient } from '@supabase/supabase-js';
import fs from 'fs';
import path from 'path';

// Parse .env manually
const envPath = path.resolve('.env');
const envFile = fs.readFileSync(envPath, 'utf8');
const env = {};
envFile.split(/\r?\n/).forEach(line => {
    if (!line || line.trim().startsWith('#')) return;
    const parts = line.split('=');
    if (parts.length >= 2) {
        const key = parts[0].trim();
        const value = parts.slice(1).join('=').trim();
        env[key] = value;
    }
});

const SUPABASE_URL = env['NEXT_PUBLIC_SUPABASE_URL'];
const SUPABASE_SERVICE_ROLE_KEY = env['SUPABASE_SERVICE_ROLE_KEY'];

const supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
    auth: {
        autoRefreshToken: false,
        persistSession: false
    }
});

async function run() {
    console.log("Fetching suggestion_lists from DB...");
    const { data, error } = await supabaseAdmin
        .from('suggestion_lists')
        .select('key, items, branch_id');
        
    if (error) {
        console.error("Error:", error);
        return;
    }
    
    data.forEach(row => {
        if (row.key === 'technicianNames' || row.key === 'supervisorNames' || row.key === 'bayNumbers') {
            console.log(`Key: ${row.key}, Branch: ${row.branch_id}`);
            console.log(JSON.stringify(row.items, null, 2));
            console.log("---------------------------------------");
        }
    });
}

run();
